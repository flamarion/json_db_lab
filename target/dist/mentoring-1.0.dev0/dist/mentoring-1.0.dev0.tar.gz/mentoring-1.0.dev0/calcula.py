#!/usr/bin/env python


class Calcula(object):
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def soma(self):
        return self.a + self.b

    def multiplica(self):
        return self.a * self.b

    def subtrai(self):
        return self.a - self.b

    def divide(self):
        return self.a / self.b